"""
src/optimize/select_deployable.py
=====================================
Phase 7 / D2.6 — second half of "one optimization pass + simulator
confirmation". Takes the surrogate's top-N candidates per regime x PCM
pair (src/optimize/search.py) and:

  1. Re-runs every one of them in the REAL simulator (non-negotiable,
     framework doc: "never report a surrogate-only number").
  2. Computes surrogate-vs-simulator error per candidate; if error >15%
     (Bug-Fix 5), trusts the simulator value and logs the mismatch.
  3. Applies the pre-declared deployable-design selection rule (framework
     doc §9.5, frozen in system_config_shared.yaml's
     `selection.pareto_tolerance_pct`):
       reject infeasible -> meet delivery/safety reliability -> within
       tolerance of best useful energy -> minimize pump energy then PCM
       mass -> prefer simpler/lower capsule count -> prefer larger
       constraint margin -> (unseen-weather re-confirmation: DEFERRED,
       medoid-only per the 40-hr cut list -- noted explicitly, not hidden).

Writes:
  results/<state>/optimized_designs.csv       -- every simulator-confirmed
                                                  candidate (the "PCM
                                                  comparison report", §9.4)
  results/<state>/deployable_design_per_regime.csv -- ONE row per regime,
                                                  the final selection
"""

import sys

import pandas as pd

from config import RESULTS_DIR
from src.design.schema import DesignVector
from src.simulation.run_case import run_case
from src.io_utils import load_system_config, load_state_config
from src.optimize.search import search_all_pairs

LARGE_ERROR_THRESHOLD_PCT = 15.0


def confirm_candidates(state: str, candidates: pd.DataFrame) -> pd.DataFrame:
    system_config = load_system_config()
    max_water_C = system_config["safety"]["max_water_temp_C"]
    max_pcm_C = system_config["safety"]["max_pcm_temp_C"]

    rows = []
    for _, cand in candidates.iterrows():
        pcm_id = None if cand["pcm_id"] == "NONE_plain_tank" else cand["pcm_id"]
        design = DesignVector(cand["capsule_diameter_m"], int(cand["n_capsule"]), cand["flow_rate_kg_s"],
                               capsule_arrangement=cand["arrangement"])
        out = run_case(state, int(cand["regime_id"]), pcm_id, design, record_hourly=True)
        if not out["valid"]:
            continue   # should not happen -- search.py already geometry-filtered
        m = out["metrics"]

        row = dict(cand)
        row.update({f"sim_{k}": v for k, v in m.items()
                    if k in ("useful_energy_kWh", "solar_fraction", "unmet_energy_kWh",
                              "pump_energy_kWh", "pcm_mass_kg", "mean_f_melt",
                              "max_water_temp_C", "max_pcm_temp_C", "n_safety_violations",
                              "residual_pct_of_collector", "delivery_temp_hours",
                              "mains_temp_C")})

        pred_e, sim_e = cand.get("pred_useful_energy_kWh"), m["useful_energy_kWh"]
        row["surrogate_vs_sim_error_pct"] = (abs(pred_e - sim_e) / sim_e * 100.0
                                              if sim_e else float("nan"))
        row["large_surrogate_error"] = row["surrogate_vs_sim_error_pct"] > LARGE_ERROR_THRESHOLD_PCT

        row["meets_temperature_safety"] = (m["max_water_temp_C"] <= max_water_C
                                            and (pcm_id is None or m["max_pcm_temp_C"] <= max_pcm_C)
                                            and m["n_safety_violations"] == 0)
        row["constraint_margin_C"] = min(
            max_water_C - m["max_water_temp_C"],
            (max_pcm_C - m["max_pcm_temp_C"]) if pcm_id is not None else 1e9,
        )
        rows.append(row)

    return pd.DataFrame(rows)


def _arrangement_rationale(winner: pd.Series, group: pd.DataFrame, noise_band_pct: float) -> str:
    """2026-09-17 (adapted from a Rajasthan-pilot change plan, source
    removed from this project after adaptation -- see
    docs_objective2/tamilnadu_phase_docs/07_PROMPT_PHASE7_OPTIMIZE_TAMILNADU.md
    step 4): compares the winning
    arrangement's simulator-confirmed useful energy against the best
    simulator-confirmed candidate of the SAME PCM under each OTHER
    arrangement in this regime. A margin inside the observed surrogate-vs-
    simulator noise band is reported as "tied within noise," not a real
    difference."""
    winner_arrangement = winner.get("arrangement")
    same_pcm = group[group["pcm_id"] == winner["pcm_id"]]
    best_by_arrangement = same_pcm.groupby("arrangement")["sim_useful_energy_kWh"].max()
    others = {a: e for a, e in best_by_arrangement.items() if a != winner_arrangement}
    if not others:
        return (f"only arrangement={winner_arrangement} was simulator-confirmed for this "
                f"regime/PCM pool -- no other arrangement to compare.")

    next_best_arrangement = max(others, key=others.get)
    next_best_energy = others[next_best_arrangement]
    winner_energy = winner["sim_useful_energy_kWh"]
    margin_pct = ((winner_energy - next_best_energy) / next_best_energy * 100.0
                  if next_best_energy else float("nan"))

    if abs(margin_pct) > noise_band_pct:
        return (f"arrangement {winner_arrangement} won by {margin_pct:.2f}% over "
                f"next-best arrangement {next_best_arrangement} "
                f"(surrogate-vs-sim noise band: {noise_band_pct:.2f}%)")
    else:
        return (f"arrangements tied within noise in this regime (margin {margin_pct:.2f}% is "
                f"inside the {noise_band_pct:.2f}% surrogate-vs-sim noise band) -- "
                f"arrangement not decisive here; next-best was {next_best_arrangement}")


def apply_selection_rule(state: str, confirmed: pd.DataFrame, noise_band_pct: float = 1.0) -> pd.DataFrame:
    """Selects the deployable PCM design per regime.

    SCOPE CORRECTION (2026-09-13, per the actual problem statement,
    presentation_review2.pdf): Objective 2 is "an AI-driven design
    optimization model to determine the optimal PCM thickness, capsule
    arrangement, number of PCM capsules, and flow rate for maximizing
    thermal energy storage" -- it presupposes a PCM design and asks for
    its optimal parameters. It does not ask whether to use PCM at all.
    The zero-mass "plain tank" option was an internal ablation/diagnostic
    baseline this implementation added on its own initiative (useful for
    Gate 3's capability check and the Phase 6 feature-importance
    analysis) -- it was never something the assignment asked to be
    eligible to win the final per-regime recommendation, and letting it
    do so was answering a different question than the one actually posed.

    So: the plain-tank rows stay in optimized_designs.csv (the full
    comparison report) for that diagnostic purpose, but are EXCLUDED from
    the pool this function selects from. Among PCM candidates only, the
    winner is the one with the highest simulator-confirmed useful energy
    (the objective's literal "maximizing thermal energy storage"),
    tie-broken by the existing pump-energy/PCM-mass/count/margin order.

    Safety is NEVER hidden: meets_temperature_safety, constraint_margin_C
    and n_safety_violations are still computed and carried through on
    every row, and a design whose margin is negative is flagged in
    `deployment_note` as needing Objective 3's active bypass before
    hardware deployment -- reported, not disqualifying the pick back to a
    non-PCM answer the assignment never asked for.

    TIE-BREAK REFINEMENT (2026-09-14, after adopting the full-MCDM
    shortlist -- see docs_objective2/15_MCDM_RERANKING.md): among
    candidates already within the pre-declared energy tolerance of the
    regime's best (i.e. already satisfying "maximize thermal energy
    storage" to within the accepted band), `meets_temperature_safety` is
    now the FIRST tie-break criterion, ahead of pump energy/mass/count.
    This was added because inspecting the full confirmed candidate pool
    showed regime 4 had 40 simulator-confirmed, genuinely safe candidates
    within the 5% tolerance band (positive constraint margin, e.g.
    n-Docosane at +2.26 C) that the OLD tie-break order (mass-first)
    passed over in favor of a lower-mass but temperature-UNSAFE
    candidate -- even though the safe alternative was not a
    energy/cost trade-off (it has HIGHER useful energy too, 1630.1 vs
    1623.2 kWh). Preferring safety among already-energy-qualified
    candidates is a strict improvement here, not a trade-off, and does
    not touch the tolerance band, the safety limits, or which PCMs are
    eligible -- it only changes which already-qualifying candidate wins
    the tie-break. Where no safe candidate exists within tolerance
    (regimes 0-3, verified empirically -- zero safe candidates in the
    full 60-candidate pool each), this criterion is a no-op and the
    previous mass-first order still decides the winner.
    """
    system_config = load_system_config()
    tol_pct = system_config["selection"]["pareto_tolerance_pct"]

    selected = []
    for regime_id, group in confirmed.groupby("regime_id"):
        pcm_only = group[group["pcm_id"] != "NONE_plain_tank"]
        if pcm_only.empty:
            print(f"  [WARN] regime {regime_id}: no PCM candidate was confirmed at all -- "
                  f"cannot produce a PCM design for this regime from the current search.")
            continue

        best_energy = pcm_only["sim_useful_energy_kWh"].max()
        within_tol = pcm_only[pcm_only["sim_useful_energy_kWh"] >= best_energy * (1 - tol_pct / 100.0)]

        within_tol = within_tol.sort_values(
            by=["meets_temperature_safety", "sim_pump_energy_kWh", "sim_pcm_mass_kg",
                "n_capsule", "constraint_margin_C"],
            ascending=[False, True, True, True, False],
        )
        winner = within_tol.iloc[0].copy()
        winner["selection_rule_pool_size"] = len(within_tol)
        winner["best_useful_energy_in_regime_kWh"] = best_energy
        winner["arrangement_rationale"] = _arrangement_rationale(winner, group, noise_band_pct)

        plain = group[group["pcm_id"] == "NONE_plain_tank"]
        if not plain.empty:
            winner["plain_tank_useful_energy_kWh"] = plain["sim_useful_energy_kWh"].iloc[0]
            winner["pcm_vs_plain_tank_pct"] = (
                (winner["sim_useful_energy_kWh"] - winner["plain_tank_useful_energy_kWh"])
                / winner["plain_tank_useful_energy_kWh"] * 100.0
            )
        winner["deployment_note"] = (
            "Meets this project's precautionary temperature-safety margin as-is."
            if winner["meets_temperature_safety"] else
            "Optimal PCM design per Objective 2's search, but exceeds the precautionary "
            "temperature-safety margin under nominal operation -- requires Objective 3's "
            "active bypass/discharge control before hardware deployment (see "
            "OBJECTIVE3_INPUTS_AND_NEXT_STEPS.md). Not a disqualification of the design; "
            "a specified precondition for deploying it."
        )
        selected.append(winner)

    return pd.DataFrame(selected)


def run_phase7(state: str, top_n_per_pair: int = 20):
    print(f"Phase 7 -- optimization pass + simulator confirmation, state={state}")
    print("Step 1/3: surrogate proposal search ...")
    candidates = search_all_pairs(state, top_n=top_n_per_pair)
    if candidates.empty:
        print("No candidates proposed -- check Phase 6 surrogate training.")
        return None, None

    print(f"\nStep 2/3: re-running {len(candidates)} candidates in the REAL simulator ...")
    confirmed = confirm_candidates(state, candidates)

    n_large_error = int(confirmed["large_surrogate_error"].sum())
    mean_error = confirmed["surrogate_vs_sim_error_pct"].mean()
    print(f"  Surrogate-vs-simulator mean error (useful energy): {mean_error:.2f}%  "
          f"({n_large_error}/{len(confirmed)} candidates >{LARGE_ERROR_THRESHOLD_PCT}% -- "
          f"large-error rule: trust the simulator value for these, already done above)")

    out_dir = RESULTS_DIR / state
    confirmed.to_csv(out_dir / "optimized_designs.csv", index=False)
    print(f"  Saved: {out_dir / 'optimized_designs.csv'}")

    print("\nStep 3/3: applying the pre-declared deployable-design selection rule ...")
    # noise_band_pct = the observed surrogate-vs-simulator mean error (step 4,
    # 2026-09-17): arrangement_rationale treats a margin smaller than this as
    # noise, not a real arrangement difference.
    deployable = apply_selection_rule(state, confirmed, noise_band_pct=float(mean_error))
    deployable.to_csv(out_dir / "deployable_design_per_regime.csv", index=False)
    print(f"  Saved: {out_dir / 'deployable_design_per_regime.csv'}")

    print("\nDeployable design per regime:")
    cols = ["regime_id", "pcm_id", "arrangement", "capsule_diameter_m", "n_capsule", "flow_rate_kg_s",
            "sim_useful_energy_kWh", "sim_solar_fraction", "sim_pump_energy_kWh",
            "sim_pcm_mass_kg", "constraint_margin_C", "surrogate_vs_sim_error_pct"]
    print(deployable[cols].to_string(index=False))
    print("\nArrangement rationale per regime:")
    for _, row in deployable.iterrows():
        print(f"  regime {row['regime_id']}: {row['arrangement_rationale']}")

    return confirmed, deployable


if __name__ == "__main__":
    state = sys.argv[1] if len(sys.argv) > 1 else "tamilnadu"
    run_phase7(state)
